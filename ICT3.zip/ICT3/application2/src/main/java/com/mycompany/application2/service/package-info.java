
/**
 * Restful services here
 */
package com.mycompany.application2.service;