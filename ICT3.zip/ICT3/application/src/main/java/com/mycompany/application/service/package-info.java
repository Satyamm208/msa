
/**
 * Restful services here
 */
package com.mycompany.application.service;