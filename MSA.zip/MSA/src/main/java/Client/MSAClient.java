/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package Client;

import javax.ws.rs.GET;
import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;

/**
 *
 * @author Shilpa
 */

@RegisterRestClient(configKey="myclient")
//@RegisterRestClient (baseUri ="http://localhost:8080/MSA/rest/example")
public interface MSAClient {
    
    @GET
    public String SayHello();
}
