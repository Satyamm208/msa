package com.mycompany.msa.service;

import entity.Book;
import java.util.Collection;
import javax.annotation.security.RolesAllowed;
import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import model.DataBean;

@Path("/example")
public class ExampleService {

    @Inject DataBean db; 
    
    @RolesAllowed("Admin")
    @GET
    @Path("getAllBook")
    @Produces(MediaType.APPLICATION_JSON)
    public Collection<Book> getAllBook()
    {
        return db.getAllBook();
    }
    
    @RolesAllowed("Admin")
    @GET
    public String SayHello() {
        return "hello this is cloud computing";
    }
    
    @RolesAllowed("Admin")
    @GET
     @Produces(MediaType.TEXT_PLAIN)
     @Path("add/{x}/{y}")
   public String sum(@PathParam("x")Integer x,@PathParam("y")Integer y)
   {
       return new Integer(x.intValue() + y.intValue()).toString();
   } 

}
