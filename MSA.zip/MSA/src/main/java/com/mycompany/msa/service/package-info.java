
/**
 * Restful services here
 */
package com.mycompany.msa.service;